#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/types.h>
#define M 3
#define K 2
#define N 3

int A[M][K] = {{1, 4},{2, 5},{3, 6}};
int B[K][N] = {{8, 7, 6},{5, 4, 3}};
int C[M][N];

struct arg_struct {
    int rows;
    int colums;
};
void *multiply(void *argss)
{
	int sum=0;
	struct arg_struct *args = (struct arg_struct *)argss;
	
		for(int j=0;j<2;j++)
		{
			sum+=(A[args->rows][j]*B[j][args->colums]);
		}
	C[args->rows][args->colums]=sum;
	
}
int main()
{
	 pthread_t some_thread;
    struct arg_struct args;
    args.rows = 5;
    args.colums = 7;
int rc;
	for(int i=0;i<M;i++)
		for(int j=0;j<N;j++)
			{
				args.rows = i;
    				args.colums = j;
				rc=pthread_create(&some_thread, NULL, &multiply, (void *) &args);
				if ( rc) 
				 {
      					  printf("Uh-oh!\n");
      					  return -1;
   			 	}
				sleep(1);
			}
pthread_join(some_thread, NULL);
	for(int i=0;i<M;i++)
	{
		for(int j=0;j<N;j++)
			{
				
      					  printf("  %d",C[i][j]);
      				
			}
		printf("\n");
 	}

    return 0;
	
}
