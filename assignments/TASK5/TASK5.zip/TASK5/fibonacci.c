#include<stdio.h>
#include<sys/types.h>
#include<pthread.h>

void* threaded_fibonacci(void* pointer)
{
 int* pointer_to_number = pointer;
    int input = *pointer_to_number;

    if (input == 0 || input == 1)
    {
        *pointer_to_number = 1;
        return NULL;
    }

    // we need one argument per thread
    int minus_one_number = input - 1;
    int minus_two_number = input - 2;

    pthread_t minus_one;
    pthread_t minus_two;
    // don't forget to check! especially that in a recursive function where the
    // recursion set actually grows instead of shrinking, you're bound to fail
    // at some point
    pthread_create(&minus_one, NULL, threaded_fibonacci, &minus_one_number);
    pthread_create(&minus_two, NULL, threaded_fibonacci, &minus_two_number);
    

    pthread_join(minus_one, NULL);
    pthread_join(minus_two, NULL);

    *pointer_to_number = minus_one_number + minus_two_number;
    return NULL;
}
int main()
{
    int value = 7;
    pthread_t thread;

    pthread_create(&thread, NULL, &threaded_fibonacci, &value);

    pthread_join(thread, NULL);

    printf("The value is %d\n", value);
    return 0;

}
